export default function LoadingIndicator() {
	return <div className="loading">Đang tải dữ liệu...</div>;
}
